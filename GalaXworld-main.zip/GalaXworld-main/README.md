## Brief Description
This repository contains the source code for my personal website, which is currently a work in progress. The website is designed with the purpose of showcasing my portfolio and skills. It is 100% handmade by me and is intended for professional use.

## Usage

As the website is under development, you can explore the existing features and portfolio items. To view the website locally, simply open the `index.html` file in your preferred web browser.

## Contributing

Contributions to this project are currently not accepted as it is a personal website. However, I appreciate your interest and feedback. Feel free to fork the repository and modify it for your own use, but please do not submit pull requests.
